<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>ksiega gosci</title>
	<style>
		body{
			background-color: black;
			color: white;
		}
		.osoba{
			float: left;
			width: 300px;
			height: 250px;
			background-color: rgba(255,255,255,0.3);
			outline: 1px solid white;
			margin-right: 50px;
			margin-bottom: 50px;
		}
		.nick{
			float: left;
			min-width: 25px;
			min-height: 25px;
			background-color: white;
			border-bottom-right-radius: 20px;
			padding-right: 20px;
			box-shadow: 0 0 15px black;
			color: black;
		}
		.emial{
			float: right;
			min-width: 25px;
			min-height: 25px;
			background-color: white;
			border-bottom-left-radius: 20px;
			padding-left: 20px;
			box-shadow: 0 0 15px black;
			color: black;
		}
		.area{
			margin: 0 auto;
			padding: 0 25px;
			width: 25px;
			min-height: 250px;
			/*background-color: red;*/
		}
	</style>
</head>
<body>
<!--
	<div class="osoba">
		<header class='nick'></header>
		<header class='emial'></header>
		<content class='area'></content>
	</div>
-->
	<?php
		$where = 'goscie.txt';
		if(file_exists($where));
		$content = file_get_contents($where);
		$osoba = explode('&&', $content);
		array_pop($osoba);

		foreach ($osoba as $value) {
			$dane = explode('||', $value);

			echo '<div class="osoba">';
			echo "<header class='nick'>$dane[0]</header>";
			echo "<header class='emial'>$dane[1]</header>";
			echo "<br><br><content class='area'>$dane[3]</content>";
			echo '</div>';
		}
	?>
</body>
</html>